<?php

define("HOST", "localhost");
define("DB", "my_ebook");
define("USER", "root");
define("PASSWORD", "iukao7");

